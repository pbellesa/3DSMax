MaxScript language defintion for SublimeText 2
Version 0.1.2
Created by CaptainKeytar/Rogier van Etten - frambooz@gmail.com
Reserved words list based on wordfile.txt by chris.p.johnson@autodesk.com
--------
Installation:

Place MaxScript.tmLanguage in your Sublime Package dir, under a directory called "MaxScript" (without quotes)
You can find your Package dir by choosing Preferences - Browse Packages...

MaxScript.JSON-tmLanguage is for if you want to adjust the definition in JSON and build it with AAAPackageDev.
--------

This is a first pass, and not at all perfect. Still have some things to learn
when it comes to language definitions. 

Please contact me with issues, suggestions and fixes:

frambooz@gmail.com

Thanks!

- Rogier van Etten (CaptainKeytar)

--------
Changes:

v0.1.2 - Added support for escaped double quotes in strings, updated installation instructions
v0.1.1 - Fixed small bug to improve function definition format
v0.1 - Initial version
--------